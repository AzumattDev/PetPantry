| `Version` | `Update Notes`    |
|-----------|-------------------|
| 1.0.0     | - Initial Release |